﻿using HugsLib;
using HugsLib.Settings;
using System;
using Verse;
using RimWorld;

namespace AutopsyTable
{
	[StaticConstructorOnStartup]
	public class Initialization : ModBase
	{
		public override string ModIdentifier => "AutopsyTable";
	}
}

